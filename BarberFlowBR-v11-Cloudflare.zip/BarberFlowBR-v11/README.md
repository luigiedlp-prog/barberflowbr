# BarberFlowBR v11 — Cloudflare + D1

Versión de desarrollo. v10.10 de producción no se modifica.

## Arquitectura
- Cloudflare Pages: interfaz pública y privada.
- Cloudflare Pages Functions: API en `/api/*`.
- Cloudflare D1: base de datos única.
- D1 binding requerido: `DB`.

## Configuración desde Cloudflare
1. Crear un D1 llamado `barberflowbr`.
2. En el proyecto Pages: Settings → Functions → Bindings → Add → D1 database.
3. Variable name: `DB`.
4. Seleccionar la base `barberflowbr`.
5. Redeploy.

La aplicación también crea el esquema mínimo automáticamente al primer request. `schema.sql` está incluido para inspección/migración manual.

## Rutas
- `/reservar/` cliente.
- `/gestion/` Santi.
- `/api/*` backend.

## Importante
Esta es una build de desarrollo. Antes de producción hay que probar en una URL real de Cloudflare: reservas consecutivas, bloqueos, cancelaciones, login, recuperación, cierre de jornada y límites.
