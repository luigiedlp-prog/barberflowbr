const DEFAULTS = {
  address: 'Italia 900',
  phone: '+54 9 2477 690562',
  pin: '3001',
  recoveryQ: '¿Cómo se llama el perro de Luis?',
  recoveryA: 'Apolo',
  schedule: {
    2: [['15:00','20:00']],
    3: [['15:00','20:00']],
    4: [['10:00','12:00'],['15:00','20:00']],
    5: [['10:00','20:00']],
    6: [['10:00','20:00']]
  }
};
const SERVICES = [
  ['s1','Corte',14000,25],
  ['s2','Corte + barba',17000,30],
  ['s3','Color',80000,120],
  ['s4','Mechas',60000,120],
  ['s5','Global',80000,150]
];

const json = (status, body, headers={}) => new Response(JSON.stringify(body), {
  status,
  headers: { 'content-type':'application/json; charset=utf-8', 'cache-control':'no-store', ...headers }
});
const uid = p => `${p}${crypto.randomUUID().replaceAll('-','').slice(0,12)}`;
const minutes = t => { const [h,m]=String(t).slice(0,5).split(':').map(Number); return h*60+m; };
const hhmm = m => `${String(Math.floor(m/60)).padStart(2,'0')}:${String(m%60).padStart(2,'0')}`;
const today = () => new Intl.DateTimeFormat('en-CA',{timeZone:'America/Argentina/Buenos_Aires'}).format(new Date());
const cleanWA = v => String(v||'').replace(/\D/g,'');

async function sha256(value){
  const data = new TextEncoder().encode(String(value));
  const digest = await crypto.subtle.digest('SHA-256', data);
  return [...new Uint8Array(digest)].map(x=>x.toString(16).padStart(2,'0')).join('');
}
function cookies(req){
  const out={};
  for(const part of (req.headers.get('cookie')||'').split(';')){
    const [k,...v]=part.trim().split('='); if(k) out[k]=v.join('=');
  }
  return out;
}
function sessionCookie(token){
  return `bf_session=${token}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=604800`;
}
function clearSessionCookie(){ return 'bf_session=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0'; }
function dateDiff(a,b){ return Math.round((new Date(`${a}T12:00:00Z`)-new Date(`${b}T12:00:00Z`))/86400000); }
function scheduleFor(date){ const dow=new Date(`${date}T12:00:00Z`).getUTCDay(); return DEFAULTS.schedule[dow]||[]; }
function validDate(date){ const d=dateDiff(date,today()); return d>=0 && d<=2; }
function slotTimes(start,duration){ const out=[]; for(let m=minutes(start);m<minutes(start)+duration;m+=15) out.push(hhmm(m)); return out; }
function startsFor(date,duration){
  if(!validDate(date)) return [];
  const out=[];
  for(const [a,b] of scheduleFor(date)){
    for(let m=minutes(a);m<=minutes(b);m+=15){
      const end=m+duration;
      if(end>1440) continue;
      out.push(hhmm(m));
    }
  }
  return out;
}
function startInsideSchedule(date,time){ return scheduleFor(date).some(([a,b])=>minutes(time)>=minutes(a)&&minutes(time)<minutes(b)); }
function allowedStart(date,time,duration){
  if(!startInsideSchedule(date,time)) return false;
  return startsFor(date,duration).includes(time);
}
async function dbInit(db){
  // The schema is installed from schema.sql before first use. This tiny bootstrap is idempotent
  // and makes a fresh D1 database self-starting even when the schema was not imported yet.
  const statements = [
    `CREATE TABLE IF NOT EXISTS bf_settings (id INTEGER PRIMARY KEY,address TEXT NOT NULL,phone TEXT NOT NULL,pin_hash TEXT NOT NULL,recovery_q TEXT NOT NULL,recovery_a_hash TEXT NOT NULL)`,
    `CREATE TABLE IF NOT EXISTS bf_services (id TEXT PRIMARY KEY,name TEXT NOT NULL,price INTEGER NOT NULL,duration INTEGER NOT NULL,online INTEGER NOT NULL DEFAULT 1)`,
    `CREATE TABLE IF NOT EXISTS bf_clients (id TEXT PRIMARY KEY,name TEXT NOT NULL,whatsapp TEXT UNIQUE NOT NULL,visits INTEGER NOT NULL DEFAULT 0,cancellations INTEGER NOT NULL DEFAULT 0,late_cancellations INTEGER NOT NULL DEFAULT 0,no_shows INTEGER NOT NULL DEFAULT 0,total_spent INTEGER NOT NULL DEFAULT 0,last_visit TEXT)`,
    `CREATE TABLE IF NOT EXISTS bf_appointments (id TEXT PRIMARY KEY,client_id TEXT NOT NULL,service_id TEXT NOT NULL,service_name TEXT NOT NULL,price INTEGER NOT NULL,duration INTEGER NOT NULL,date TEXT NOT NULL,time TEXT NOT NULL,status TEXT NOT NULL,source TEXT NOT NULL DEFAULT 'online',notes TEXT DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,cancelled_at TEXT,late_cancel INTEGER NOT NULL DEFAULT 0)`,
    `CREATE TABLE IF NOT EXISTS bf_slots (date TEXT NOT NULL,time TEXT NOT NULL,owner_id TEXT NOT NULL,kind TEXT NOT NULL,PRIMARY KEY(date,time))`,
    `CREATE TABLE IF NOT EXISTS bf_blocks (id TEXT PRIMARY KEY,date TEXT NOT NULL,start_time TEXT NOT NULL,end_time TEXT NOT NULL,whole_day INTEGER NOT NULL DEFAULT 0,reason TEXT DEFAULT '')`,
    `CREATE TABLE IF NOT EXISTS bf_notifications (id TEXT PRIMARY KEY,kind TEXT NOT NULL,title TEXT NOT NULL,body TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,seen INTEGER NOT NULL DEFAULT 0)`,
    `CREATE TABLE IF NOT EXISTS bf_sessions (token_hash TEXT PRIMARY KEY,expires_at TEXT NOT NULL)`,
    `CREATE TABLE IF NOT EXISTS bf_daily_summaries (date TEXT PRIMARY KEY,turns INTEGER NOT NULL DEFAULT 0,revenue INTEGER NOT NULL DEFAULT 0,cancelled INTEGER NOT NULL DEFAULT 0)`,
    `CREATE INDEX IF NOT EXISTS idx_appt_date_time ON bf_appointments(date,time)`,
    `CREATE INDEX IF NOT EXISTS idx_appt_client ON bf_appointments(client_id,date)`,
    `CREATE INDEX IF NOT EXISTS idx_blocks_date ON bf_blocks(date)`,
    `CREATE INDEX IF NOT EXISTS idx_notifications_seen ON bf_notifications(seen,created_at)`
  ];
  await db.batch(statements.map(s=>db.prepare(s)));
  const st=await db.prepare('SELECT * FROM bf_settings WHERE id=1').first();
  if(!st){
    await db.prepare('INSERT INTO bf_settings(id,address,phone,pin_hash,recovery_q,recovery_a_hash) VALUES(1,?,?,?,?,?)')
      .bind(DEFAULTS.address,DEFAULTS.phone,await sha256(DEFAULTS.pin),DEFAULTS.recoveryQ,await sha256(DEFAULTS.recoveryA.toLowerCase())).run();
  }
  const n=await db.prepare('SELECT COUNT(*) AS n FROM bf_services').first();
  if(Number(n?.n||0)===0){
    await db.batch(SERVICES.map(s=>db.prepare('INSERT INTO bf_services(id,name,price,duration,online) VALUES(?,?,?,?,1)').bind(...s)));
  }
}
async function rollover(db){
  const now=today();
  const old=await db.prepare(`SELECT * FROM bf_appointments WHERE date<? AND status='pending'`).all(now);
  if(!old.results.length) return;
  const stm=[];
  for(const a of old.results){
    stm.push(db.prepare(`UPDATE bf_appointments SET status='cancelled',cancelled_at=CURRENT_TIMESTAMP WHERE id=?`).bind(a.id));
    stm.push(db.prepare(`DELETE FROM bf_slots WHERE owner_id=?`).bind(a.id));
    stm.push(db.prepare(`UPDATE bf_clients SET cancellations=cancellations+1 WHERE id=?`).bind(a.client_id));
    stm.push(db.prepare(`INSERT INTO bf_daily_summaries(date,turns,revenue,cancelled) VALUES(?,0,0,1) ON CONFLICT(date) DO UPDATE SET cancelled=cancelled+1`).bind(a.date));
  }
  await db.batch(stm);
}
async function settings(db){ return db.prepare('SELECT * FROM bf_settings WHERE id=1').first(); }
async function isAdmin(req,db){
  const raw=cookies(req).bf_session; if(!raw) return false;
  const h=await sha256(raw);
  const r=await db.prepare('SELECT 1 FROM bf_sessions WHERE token_hash=? AND expires_at>CURRENT_TIMESTAMP').bind(h).first();
  return !!r;
}
async function notify(db,kind,title,body){ await db.prepare('INSERT INTO bf_notifications(id,kind,title,body) VALUES(?,?,?,?)').bind(uid('n'),kind,title,body).run(); }
async function service(db,id){ return db.prepare('SELECT * FROM bf_services WHERE id=?').bind(id).first(); }
async function occupiedSlots(db,date){ return db.prepare('SELECT time FROM bf_slots WHERE date=? ORDER BY time').bind(date).all(); }
async function publicData(db){
  const st=await settings(db); const sv=await db.prepare('SELECT id,name,price,duration FROM bf_services WHERE online=1 ORDER BY name').all();
  return {address:st.address,phone:st.phone,services:sv.results,schedule:DEFAULTS.schedule,days:3,today:today()};
}
async function canReserve(db,date,time,duration){
  if(!validDate(date)||!allowedStart(date,time,duration)) return false;
  const slots=slotTimes(time,duration);
  if(slots.some(t=>minutes(t)>=1440)) return false;
  for(const t of slots){ const x=await db.prepare('SELECT 1 FROM bf_slots WHERE date=? AND time=?').bind(date,t).first(); if(x) return false; }
  return true;
}
async function clientByWA(db,wa){ return db.prepare('SELECT * FROM bf_clients WHERE whatsapp=?').bind(wa).first(); }
async function insertAppointment(db,{id,clientId,s,date,time,status='pending',source='online',notes=''}){
  const slots=slotTimes(time,s.duration);
  const stm=[db.prepare(`INSERT INTO bf_appointments(id,client_id,service_id,service_name,price,duration,date,time,status,source,notes) VALUES(?,?,?,?,?,?,?,?,?,?,?)`).bind(id,clientId,s.id,s.name,s.price,s.duration,date,time,status,source,notes)];
  for(const t of slots) stm.push(db.prepare('INSERT INTO bf_slots(date,time,owner_id,kind) VALUES(?,?,?,?)').bind(date,t,id,'appointment'));
  await db.batch(stm);
}
async function cancelAppointment(db,a,late=false){
  await db.batch([
    db.prepare(`UPDATE bf_appointments SET status='cancelled',cancelled_at=CURRENT_TIMESTAMP,late_cancel=? WHERE id=?`).bind(late?1:0,a.id),
    db.prepare('DELETE FROM bf_slots WHERE owner_id=?').bind(a.id),
    db.prepare(`UPDATE bf_clients SET cancellations=cancellations+1,late_cancellations=late_cancellations+? WHERE id=?`).bind(late?1:0,a.client_id)
  ]);
}

export async function onRequest(context){
  const {request,env,params}=context;
  const db=env.DB;
  if(!db) return json(500,{error:'Falta configurar el binding D1 llamado DB.'});
  try{
    await dbInit(db);
    await rollover(db);
    const path='/' + (Array.isArray(params.path)?params.path.join('/'):(params.path||''));
    const method=request.method;
    let body={};
    if(method!=='GET'&&method!=='HEAD') { try{ body=await request.json(); }catch{} }

    if(method==='GET'&&path==='/public') return json(200,await publicData(db));

    if(method==='GET'&&path==='/availability'){
      const u=new URL(request.url),date=u.searchParams.get('date'),serviceId=u.searchParams.get('service');
      const s=await service(db,serviceId);
      if(!date||!s||!s.online) return json(400,{error:'Datos inválidos'});
      const times=startsFor(date,s.duration).filter(async()=>true);
      const free=[];
      for(const t of times) if(await canReserve(db,date,t,s.duration)) free.push(t);
      return json(200,{date,service:s.id,times:free});
    }

    if(method==='POST'&&path==='/book'){
      const {service:serviceId,date,time,name,whatsapp}=body; const s=await service(db,serviceId); const wa=cleanWA(whatsapp);
      if(!s||!s.online||!date||!time||!String(name||'').trim()||wa.length<8) return json(400,{error:'Completá todos los datos'});
      if(!validDate(date)) return json(400,{error:'Solo se pueden reservar hoy, mañana o pasado mañana'});
      const id=uid('a'); const cid=uid('c'); const old=await clientByWA(db,wa); const clientId=old?.id||cid;
      const stm=[];
      if(!old) stm.push(db.prepare('INSERT INTO bf_clients(id,name,whatsapp) VALUES(?,?,?)').bind(clientId,String(name).trim(),wa));
      else stm.push(db.prepare('UPDATE bf_clients SET name=? WHERE id=?').bind(String(name).trim(),clientId));
      if(!await canReserve(db,date,time,s.duration)) return json(409,{error:'Ese horario ya no está disponible'});
      stm.push(db.prepare(`INSERT INTO bf_appointments(id,client_id,service_id,service_name,price,duration,date,time,status,source) VALUES(?,?,?,?,?,?,?,?,?,?)`).bind(id,clientId,s.id,s.name,s.price,s.duration,date,time,'pending','online'));
      for(const t of slotTimes(time,s.duration)) stm.push(db.prepare('INSERT INTO bf_slots(date,time,owner_id,kind) VALUES(?,?,?,?)').bind(date,t,id,'appointment'));
      stm.push(db.prepare('INSERT INTO bf_notifications(id,kind,title,body) VALUES(?,?,?,?)').bind(uid('n'),'booking','Nuevo turno online',`${String(name).trim()} · ${s.name} · ${date} · ${time}`));
      try { await db.batch(stm); } catch(e) { return json(409,{error:'Ese horario acaba de ser ocupado. Elegí otro.'}); }
      const st=await settings(db); return json(200,{id,service:s.name,price:s.price,duration:s.duration,date,time,address:st.address,phone:st.phone});
    }

    if(method==='GET'&&path==='/my-appointments'){
      const u=new URL(request.url),wa=cleanWA(u.searchParams.get('whatsapp')); const r=await db.prepare(`SELECT a.*,c.name,c.whatsapp FROM bf_appointments a JOIN bf_clients c ON c.id=a.client_id WHERE c.whatsapp=? AND a.date>=? AND a.status='pending' ORDER BY a.date,a.time`).bind(wa,today()).all(); const st=await settings(db);
      return json(200,{appointments:r.results,address:st.address,phone:st.phone});
    }

    if(method==='POST'&&path==='/cancel'){
      const {id,whatsapp}=body,wa=cleanWA(whatsapp); const a=await db.prepare(`SELECT a.*,c.whatsapp FROM bf_appointments a JOIN bf_clients c ON c.id=a.client_id WHERE a.id=? AND c.whatsapp=?`).bind(id,wa).first();
      if(!a||a.status!=='pending') return json(404,{error:'Turno no encontrado'});
      const ap=Date.parse(`${a.date}T${String(a.time).slice(0,5)}:00-03:00`); const hours=(ap-Date.now())/3600000; if(hours<0)return json(400,{error:'El turno ya comenzó o pasó'});
      const late=hours<1; await cancelAppointment(db,a,late);
      if(late) await notify(db,'late_cancel','Cancelación con menos de 1 hora',`${a.service_name} · ${a.date} · ${String(a.time).slice(0,5)} · corresponde informar 50% (${Math.round(a.price/2)})`); else await notify(db,'cancel','Turno cancelado',`${a.service_name} · ${a.date} · ${String(a.time).slice(0,5)}`);
      return json(200,{ok:true,late,halfPrice:late?Math.round(a.price/2):0});
    }

    if(method==='POST'&&path==='/login'){
      const st=await settings(db); if(await sha256(body.pin||'')!==st.pin_hash) return json(401,{error:'PIN incorrecto'});
      const raw=crypto.randomUUID()+crypto.randomUUID(), h=await sha256(raw); await db.prepare(`INSERT INTO bf_sessions(token_hash,expires_at) VALUES(?,datetime('now','+7 days'))`).bind(h).run();
      return json(200,{ok:true},{'set-cookie':sessionCookie(raw)});
    }

    if(method==='POST'&&path==='/recover'){
      const st=await settings(db); if(await sha256(String(body.answer||'').trim().toLowerCase())!==st.recovery_a_hash)return json(401,{error:'Respuesta incorrecta'});
      if(!/^\d{4}$/.test(String(body.newPin||'')))return json(400,{error:'El PIN debe tener 4 dígitos'});
      await db.prepare('UPDATE bf_settings SET pin_hash=? WHERE id=1').bind(await sha256(body.newPin)).run(); return json(200,{ok:true});
    }

    if(!(await isAdmin(request,db))) return json(401,{error:'No autorizado'});

    if(method==='GET'&&path==='/admin'){
      const [st,sv,ap,cl,bl,n,summ]=await Promise.all([
        settings(db),
        db.prepare('SELECT id,name,price,duration,online FROM bf_services ORDER BY name').all(),
        db.prepare(`SELECT a.*,c.name,c.whatsapp FROM bf_appointments a JOIN bf_clients c ON c.id=a.client_id WHERE a.date>=? ORDER BY a.date,a.time`).bind(today()).all(),
        db.prepare('SELECT * FROM bf_clients ORDER BY name').all(),
        db.prepare('SELECT * FROM bf_blocks WHERE date>=? ORDER BY date,start_time').bind(today()).all(),
        db.prepare('SELECT * FROM bf_notifications WHERE seen=0 ORDER BY created_at DESC').all(),
        db.prepare("SELECT * FROM bf_daily_summaries WHERE date>=date(?,'-2 months') ORDER BY date DESC").bind(today()).all()
      ]);
      return json(200,{settings:{address:st.address,phone:st.phone,recoveryQ:st.recovery_q},services:sv.results,appointments:ap.results,clients:cl.results,blocks:bl.results,notifications:n.results,summaries:summ.results,schedule:DEFAULTS.schedule,today:today()});
    }
    if(method==='POST'&&path==='/admin/settings'){await db.prepare('UPDATE bf_settings SET address=?,phone=? WHERE id=1').bind(body.address,body.phone).run();return json(200,{ok:true});}
    if(method==='POST'&&path==='/admin/pin'){if(!/^\d{4}$/.test(String(body.pin||'')))return json(400,{error:'El PIN debe tener 4 dígitos'});await db.prepare('UPDATE bf_settings SET pin_hash=? WHERE id=1').bind(await sha256(body.pin)).run();return json(200,{ok:true});}
    if(method==='POST'&&path==='/admin/recovery'){await db.prepare('UPDATE bf_settings SET recovery_q=?,recovery_a_hash=? WHERE id=1').bind(body.question,await sha256(String(body.answer||'').trim().toLowerCase())).run();return json(200,{ok:true});}
    if(method==='POST'&&path==='/admin/service'){
      if(body.id) await db.prepare('UPDATE bf_services SET name=?,price=?,duration=?,online=? WHERE id=?').bind(body.name,Number(body.price),Number(body.duration),body.online?1:0,body.id).run();
      else await db.prepare('INSERT INTO bf_services(id,name,price,duration,online) VALUES(?,?,?,?,?)').bind(uid('s'),body.name,Number(body.price),Number(body.duration),body.online===false?0:1).run();
      return json(200,{ok:true});
    }
    if(method==='POST'&&path==='/admin/appointment'){
      const {id,clientId,date,time,serviceId,status='pending',notes=''}=body; const s=await service(db,serviceId); if(!s)return json(400,{error:'Servicio inválido'});
      if(id){
        const old=await db.prepare('SELECT * FROM bf_appointments WHERE id=?').bind(id).first(); if(!old)return json(404,{error:'Turno no encontrado'});
        if(old.status==='done')return json(400,{error:'Los turnos hechos no se editan'});
        await db.batch([db.prepare('DELETE FROM bf_slots WHERE owner_id=?').bind(id),db.prepare('UPDATE bf_appointments SET date=?,time=?,service_id=?,service_name=?,price=?,duration=?,status=?,notes=? WHERE id=?').bind(date,time,s.id,s.name,s.price,s.duration,status,notes,id)]);
        if(status!=='cancelled'){
          if(!await canReserve(db,date,time,s.duration))return json(409,{error:'Horario ocupado'});
          await db.batch(slotTimes(time,s.duration).map(t=>db.prepare('INSERT INTO bf_slots(date,time,owner_id,kind) VALUES(?,?,?,?)').bind(date,t,id,'appointment')));
        }
        return json(200,{ok:true});
      }
      if(!clientId||!validDate(date)||!await canReserve(db,date,time,s.duration))return json(409,{error:'Horario ocupado o datos inválidos'});
      await insertAppointment(db,{id:uid('a'),clientId,s,date,time,status,source:'manual',notes}); return json(200,{ok:true});
    }
    if(method==='POST'&&path==='/admin/block'){
      const {date,start,end,wholeDay,reason}=body; let affected=[];
      if(wholeDay) affected=(await db.prepare(`SELECT a.*,c.name,c.whatsapp FROM bf_appointments a JOIN bf_clients c ON c.id=a.client_id WHERE a.date=? AND a.status='pending'`).bind(date).all()).results;
      else affected=(await db.prepare(`SELECT a.*,c.name,c.whatsapp FROM bf_appointments a JOIN bf_clients c ON c.id=a.client_id WHERE a.date=? AND a.status='pending' AND a.time<? AND time(a.time, '+'||a.duration||' minutes')>?`).bind(date,end,start).all()).results;
      if(affected.length&&!body.confirm)return json(409,{affected});
      const bid=uid('b'); const bStart=wholeDay?'00:00':start,bEnd=wholeDay?'23:59':end;
      const stm=[db.prepare('INSERT INTO bf_blocks(id,date,start_time,end_time,whole_day,reason) VALUES(?,?,?,?,?,?)').bind(bid,date,bStart,bEnd,wholeDay?1:0,reason||'')];
      const blockSlots=[]; if(wholeDay){for(let m=0;m<1440;m+=15)blockSlots.push(hhmm(m));}else{for(let m=minutes(start);m<minutes(end);m+=15)blockSlots.push(hhmm(m));}
      for(const t of blockSlots)stm.push(db.prepare('INSERT INTO bf_slots(date,time,owner_id,kind) VALUES(?,?,?,?)').bind(date,t,bid,'block'));
      if(affected.length&&body.cancelAffected){for(const a of affected){stm.push(db.prepare(`UPDATE bf_appointments SET status='cancelled',cancelled_at=CURRENT_TIMESTAMP WHERE id=?`).bind(a.id));stm.push(db.prepare('DELETE FROM bf_slots WHERE owner_id=?').bind(a.id));stm.push(db.prepare('UPDATE bf_clients SET cancellations=cancellations+1 WHERE id=?').bind(a.client_id));}}
      try{await db.batch(stm);}catch(e){return json(409,{error:'No se pudo aplicar el bloqueo porque se superpone con otro horario.'});}
      return json(200,{ok:true,affected:affected.length});
    }
    if(method==='POST'&&path==='/admin/notifications/read'){await db.prepare('UPDATE bf_notifications SET seen=1 WHERE id=?').bind(body.id).run();return json(200,{ok:true});}
    if(method==='POST'&&path==='/admin/finish'){
      const a=await db.prepare('SELECT * FROM bf_appointments WHERE id=?').bind(body.id).first(); if(!a||a.date!==today()||a.status!=='pending')return json(400,{error:'Solo se puede finalizar un turno pendiente de hoy'});
      await db.batch([
        db.prepare(`UPDATE bf_appointments SET status='done' WHERE id=?`).bind(a.id),
        db.prepare('DELETE FROM bf_slots WHERE owner_id=?').bind(a.id),
        db.prepare('UPDATE bf_clients SET visits=visits+1,total_spent=total_spent+?,last_visit=? WHERE id=?').bind(a.price,today(),a.client_id),
        db.prepare(`INSERT INTO bf_daily_summaries(date,turns,revenue,cancelled) VALUES(?,?,?,0) ON CONFLICT(date) DO UPDATE SET turns=turns+1,revenue=revenue+excluded.revenue`).bind(today(),1,a.price)
      ]); return json(200,{ok:true});
    }
    if(method==='POST'&&path==='/logout'){const raw=cookies(request).bf_session;if(raw)await db.prepare('DELETE FROM bf_sessions WHERE token_hash=?').bind(await sha256(raw)).run();return json(200,{ok:true},{'set-cookie':clearSessionCookie()});}
    return json(404,{error:'Ruta no encontrada'});
  }catch(e){ console.error(e); return json(500,{error:'Error interno'}); }
}
