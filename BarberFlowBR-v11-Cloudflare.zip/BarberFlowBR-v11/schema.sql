PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS bf_settings (
  id INTEGER PRIMARY KEY,
  address TEXT NOT NULL,
  phone TEXT NOT NULL,
  pin_hash TEXT NOT NULL,
  recovery_q TEXT NOT NULL,
  recovery_a_hash TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS bf_services (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  price INTEGER NOT NULL,
  duration INTEGER NOT NULL,
  online INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS bf_clients (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  whatsapp TEXT UNIQUE NOT NULL,
  visits INTEGER NOT NULL DEFAULT 0,
  cancellations INTEGER NOT NULL DEFAULT 0,
  late_cancellations INTEGER NOT NULL DEFAULT 0,
  no_shows INTEGER NOT NULL DEFAULT 0,
  total_spent INTEGER NOT NULL DEFAULT 0,
  last_visit TEXT
);

CREATE TABLE IF NOT EXISTS bf_appointments (
  id TEXT PRIMARY KEY,
  client_id TEXT NOT NULL REFERENCES bf_clients(id),
  service_id TEXT NOT NULL,
  service_name TEXT NOT NULL,
  price INTEGER NOT NULL,
  duration INTEGER NOT NULL,
  date TEXT NOT NULL,
  time TEXT NOT NULL,
  status TEXT NOT NULL,
  source TEXT NOT NULL DEFAULT 'online',
  notes TEXT DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  cancelled_at TEXT,
  late_cancel INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS bf_slots (
  date TEXT NOT NULL,
  time TEXT NOT NULL,
  owner_id TEXT NOT NULL,
  kind TEXT NOT NULL,
  PRIMARY KEY(date,time)
);

CREATE TABLE IF NOT EXISTS bf_blocks (
  id TEXT PRIMARY KEY,
  date TEXT NOT NULL,
  start_time TEXT NOT NULL,
  end_time TEXT NOT NULL,
  whole_day INTEGER NOT NULL DEFAULT 0,
  reason TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS bf_notifications (
  id TEXT PRIMARY KEY,
  kind TEXT NOT NULL,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  seen INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS bf_sessions (
  token_hash TEXT PRIMARY KEY,
  expires_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS bf_daily_summaries (
  date TEXT PRIMARY KEY,
  turns INTEGER NOT NULL DEFAULT 0,
  revenue INTEGER NOT NULL DEFAULT 0,
  cancelled INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_appt_date_time ON bf_appointments(date,time);
CREATE INDEX IF NOT EXISTS idx_appt_client ON bf_appointments(client_id,date);
CREATE INDEX IF NOT EXISTS idx_blocks_date ON bf_blocks(date);
CREATE INDEX IF NOT EXISTS idx_notifications_seen ON bf_notifications(seen,created_at);
